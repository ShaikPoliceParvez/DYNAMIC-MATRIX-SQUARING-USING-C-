1) There are four code for four algorithms.
2) To compile the tas file g++ Assgn3_TAS_Src-CS22BTECH11052.cpp and run it by ./a.out.
3) To compile the cas file g++ Assgn3_CAS_Src-CS22BTECH11052.cpp and run it by ./a.out.
4) To compile the boundedcas file g++ Assgn3_BoundedCAS_Src-CS22BTECH11052.cpp and run it by ./a.out.
5) To compile the atomic file g++ Assgn3_Atomic_Src-CS22BTECH11052.cpp and run it by ./a.out.
6) output files will be like out_algorithm.txt
   eg: for tas output file will be out_tas.txt