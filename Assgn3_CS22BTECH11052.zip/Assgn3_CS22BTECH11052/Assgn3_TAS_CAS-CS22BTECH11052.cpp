#include <iostream>
#include <fstream>
#include <vector>
#include <atomic>
#include <chrono>
#include <pthread.h>

using namespace std;
using namespace std::chrono;
int com = 0;
int loc = 0;

struct ThreadData
{
    const vector<vector<int>> *A;
    vector<vector<int>> *result;
    int rowinc;
    int size;
};

vector<vector<int>> readMatrix(const string &filename, int &N, int &K, int &P)
{
    ifstream file(filename);
    if (!file.is_open())
    {
        cerr << "Error opening file: " << filename << endl;
        exit(EXIT_FAILURE);
    }

    file >> N >> K >> P;
    vector<vector<int>> matrix(N, vector<int>(N));
    for (int i = 0; i < N; ++i)
    {
        for (int j = 0; j < N; ++j)
        {
            file >> matrix[i][j];
        }
    }

    file.close();
    return matrix;
}

int compare_and_swap(int *value, int expected, int newvalue)
{
    int temp = *value;
    if (*value == expected)
        *value = newvalue;
    return temp;
}

void *computeSquare(void *args)
{
    ThreadData *data = static_cast<ThreadData *>(args);
    const vector<vector<int>> &A = *(data->A);
    vector<vector<int>> &result = *(data->result);
    int N = data->size;
    int P = data->rowinc;
    while (true)
    {
        if (com >= N)
        {
            break;
        }
        while (!compare_and_swap(&loc, 0, 1))
            ;
        int start = com;
        com += P;
        loc = 0;
        int end = min(start + P, N);
        int N = A.size();
        for (int i = start; i < end; ++i)
        {
            for (int j = 0; j < N; ++j)
            {
                int sum = 0;
                for (int k = 0; k < N; ++k)
                {
                    sum += A[i][k] * A[k][j];
                }
                result[i][j] = sum;
            }
        }
    }
    pthread_exit(NULL);
}

int main()
{
    int N, K, P;
    vector<vector<int>> A = readMatrix("inp.txt", N, K, P);
    vector<vector<int>> result(N, vector<int>(N, 0));
    auto start = high_resolution_clock::now();
    pthread_t threads[K];
    ThreadData threadData[K];

    int chunk_size = N / K;
    for (int i = 0; i < K; ++i)
    {
        threadData[i] = {&A, &result, P, N};
        pthread_create(&threads[i], NULL, computeSquare, &threadData[i]);
    }

    for (int i = 0; i < K; ++i)
    {
        pthread_join(threads[i], NULL);
    }

    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);
    double time_taken = duration.count();

    ofstream outfile("out_cas.txt");
    if (!outfile.is_open())
    {
        cerr << "Error opening output file: out.txt" << endl;
        exit(EXIT_FAILURE);
    }
    outfile << "Resulting Square Matrix:" << endl;
    for (int i = 0; i < N; ++i)
    {
        for (int j = 0; j < N; ++j)
        {
            outfile << result[i][j] << " ";
        }
        outfile << endl;
    }

    outfile << "Time taken: " << time_taken << " microseconds" << endl;
    outfile.close();
    return 0;
}

// clang++ -std=c++11 1.cpp