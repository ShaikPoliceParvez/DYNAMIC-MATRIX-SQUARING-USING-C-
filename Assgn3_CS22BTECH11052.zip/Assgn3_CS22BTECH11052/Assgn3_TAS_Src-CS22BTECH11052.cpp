#include <iostream>
#include <fstream>
#include <vector>
#include <chrono>
#include <atomic>
#include <pthread.h>

using namespace std;
using namespace std::chrono;

int com = 0;
atomic_flag loc = ATOMIC_FLAG_INIT;

struct ThreadData
{
    const vector<vector<int>> *A;
    vector<vector<int>> *result;
    int rowinc;
    int size;
};

vector<vector<int>> readMatrix(const string &filename, int &N, int &K, int &P)
{
    ifstream file(filename);
    if (!file.is_open())
    {
        cerr << "Error opening file: " << filename << endl;
        exit(EXIT_FAILURE);
    }

    file >> N >> K >> P;
    vector<vector<int>> matrix(N, vector<int>(N));
    for (int i = 0; i < N; ++i)
    {
        for (int j = 0; j < N; ++j)
        {
            file >> matrix[i][j];
        }
    }

    file.close();
    return matrix;
}

void *computeSquare(void *args)
{
    ThreadData *data = static_cast<ThreadData *>(args);
    const vector<vector<int>> &A = *(data->A);
    vector<vector<int>> &result = *(data->result);
    int N = data->size;
    int P = data->rowinc;
    while (true)
    {
        if (com >= N)
        {
            break; 
        }
        atomic_flag_test_and_set_explicit(&loc, memory_order_acquire);
        int start = com;
        com += P;
        atomic_flag_clear_explicit(&loc, memory_order_release);
        int end = min(start + P, N);
        int N = A.size();
        for (int i = start; i < end; ++i)
        {
            for (int j = 0; j < N; ++j)
            {
                int sum = 0;
                for (int k = 0; k < N; ++k)
                {
                    sum += A[i][k] * A[k][j];
                }
                result[i][j] = sum;
            }
        }
    }
    pthread_exit(NULL);
}

int main()
{
    int N, K, P;
    vector<vector<int>> A = readMatrix("inp.txt", N, K, P);
    vector<vector<int>> result(N, vector<int>(N, 0));
    auto start = high_resolution_clock::now();
    pthread_t threads[K];
    ThreadData threadData[K];

    int chunk_size = N / K;
    for (int i = 0; i < K; ++i)
    {
        threadData[i] = {&A, &result, P, N};
        pthread_create(&threads[i], NULL, computeSquare, &threadData[i]);
    }

    for (int i = 0; i < K; ++i)
    {
        pthread_join(threads[i], NULL);
    }

    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);
    double time_taken = duration.count();

    ofstream outfile("out_tas.txt");
    if (!outfile.is_open())
    {
        cerr << "Error opening output file: out.txt" << endl;
        exit(EXIT_FAILURE);
    }
    outfile << "Resulting Square Matrix:" << endl;
    for (int i = 0; i < N; ++i)
    {
        for (int j = 0; j < N; ++j)
        {
            outfile << result[i][j] << " ";
        }
        outfile << endl;
    }

    outfile << "Time taken: " << time_taken << " microseconds" << endl;
    outfile.close();
    return 0;
}
